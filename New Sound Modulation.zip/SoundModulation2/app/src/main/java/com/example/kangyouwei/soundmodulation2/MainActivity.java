package com.example.kangyouwei.soundmodulation2;
/*
import android.app.Activity;
import android.media.AudioManager;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.media.SoundPool;
import android.widget.TextView;
*/

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.app.Activity;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.util.Log;
import java.lang.Math;
import java.util.Arrays;

public class MainActivity extends Activity {
    /*
    float defaultVolume = (float) 0.5;
    float changeVolume = (float) 0.1;
    float playVolume = defaultVolume;
    int octaveLevel = (int)1;
    int streamID;
    float playBackRate = (float) 1.0;
    String volumeInString;
    static SoundPool sp;
    static int soundId;
    static AudioManager amg;
    TextView volume;
*/
    int samplingRate = 44100;
    boolean isRunning = false;
    int amp = 10000;
    double twopi = 8.*Math.atan(1.);
    int midi = 60;
    double ph = 0.0;
    int buffsize;
    double multiplier = 16;
    int portion = 4;
    long timeFrame = 5000;
    boolean playSound = true;
    int findNotes = midi%12;

    String noteInString;
    TextView notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
/*
        volume = (TextView) findViewById(R.id.volume);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            sp = new SoundPool.Builder()
                    .setMaxStreams(1)
                    .build();
        } else {
            sp = new SoundPool(1, AudioManager.STREAM_MUSIC, 1);
        }
        soundId = sp.load(this, R.raw.cguitarchord,1);
        amg = (AudioManager)getSystemService(this.AUDIO_SERVICE);
*/
        final Button play = (Button) findViewById(R.id.play);
        final Button stop = (Button) findViewById(R.id.stop);

        final Button softer = (Button) findViewById(R.id.softer);
        final Button louder = (Button) findViewById(R.id.louder);
        final Button higher = (Button) findViewById(R.id.higherOctave);
        final Button lower = (Button) findViewById(R.id.lowerOctave);
        final Button slower = (Button) findViewById(R.id.slower);
        final Button faster = (Button) findViewById(R.id.faster);
        final Button previous = (Button) findViewById(R.id.previous);
        final Button next = (Button) findViewById(R.id.next);

        notes = (TextView) findViewById(R.id.note);

        switch (findNotes){
            case 0: noteInString = "C";
                break;
            case 1: noteInString = "C#";
                break;
            case 2: noteInString = "D";
                break;
            case 3: noteInString = "D#";
                break;
            case 4: noteInString = "E";
                break;
            case 5: noteInString = "F";
                break;
            case 6: noteInString = "F#";
                break;
            case 7: noteInString = "G";
                break;
            case 8: noteInString = "G#";
                break;
            case 9: noteInString = "A";
                break;
            case 10: noteInString = "A#";
                break;
            case 11: noteInString = "B";
                break;

        }

        notes.setText(noteInString);



        buffsize = AudioTrack.getMinBufferSize(samplingRate,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        buffsize = (int)(buffsize*multiplier);
        // create an audiotrack object
        final AudioTrack audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC,
                samplingRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, buffsize,
                AudioTrack.MODE_STATIC);

        short samples[] = new short[buffsize];


        for(int i=0; i < buffsize; i++) {
                samples[i] = 0;
        }
        audioTrack.write(samples, 0, buffsize);
        audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
        audioTrack.play();



        play.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                audioTrack.stop();
                audioTrack.flush();
                double freq = convertMidiToFreq(midi);
                isRunning = true;
                short samples[] = new short[buffsize];

                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();


                // synthesis loop
                /*
                while(isRunning){
                    long intervalTime = System.currentTimeMillis()-timeBased;

                    if (intervalTime>interval){
                        playSound = !playSound;
                        timeBased = System.currentTimeMillis();
                    }


                    if (playSound){

                        audioTrack.write(samples, 0, buffsize);
                        audioTrack.play();


                    }
                    else{
                        audioTrack.pause();
                        ph = 0;

                    }
                    if (System.currentTimeMillis()-startTime>timeFrame){
                        isRunning = false;
                        audioTrack.pause();
                        audioTrack.flush();
                        break;
                    }

                }*/
            }
        });

        softer.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                amp = amp/2;
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        louder.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                amp = amp*2;
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        higher.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                midi = midi+12;
                if (midi>127){
                    midi = 127;
                }
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        lower.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                midi = midi - 12;
                if(midi<0){
                    midi = 0;
                }
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        slower.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                portion = portion -1;
                if (portion<2){
                    portion =2;
                }
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        faster.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                portion = portion+1;
                if (portion > 10) {

                    portion = 10;
                }
                audioTrack.stop();
                audioTrack.flush();


                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        next.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                midi = midi+1;
                if (midi>127){
                    midi = 127;
                }
                findNotes = midi%12;
                switch (findNotes){
                    case 0: noteInString = "C";
                        break;
                    case 1: noteInString = "C#";
                        break;
                    case 2: noteInString = "D";
                        break;
                    case 3: noteInString = "D#";
                        break;
                    case 4: noteInString = "E";
                        break;
                    case 5: noteInString = "F";
                        break;
                    case 6: noteInString = "F#";
                        break;
                    case 7: noteInString = "G";
                        break;
                    case 8: noteInString = "G#";
                        break;
                    case 9: noteInString = "A";
                        break;
                    case 10: noteInString = "A#";
                        break;
                    case 11: noteInString = "B";
                        break;

                }

                notes.setText(noteInString);

                audioTrack.stop();
                audioTrack.flush();

                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();
            }
        });
        previous.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                midi = midi - 1;
                if(midi<0){
                    midi = 0;
                }
                findNotes = midi%12;
                switch (findNotes){
                    case 0: noteInString = "C";
                        break;
                    case 1: noteInString = "C#";
                        break;
                    case 2: noteInString = "D";
                        break;
                    case 3: noteInString = "D#";
                        break;
                    case 4: noteInString = "E";
                        break;
                    case 5: noteInString = "F";
                        break;
                    case 6: noteInString = "F#";
                        break;
                    case 7: noteInString = "G";
                        break;
                    case 8: noteInString = "G#";
                        break;
                    case 9: noteInString = "A";
                        break;
                    case 10: noteInString = "A#";
                        break;
                    case 11: noteInString = "B";
                        break;

                }

                notes.setText(noteInString);

                audioTrack.stop();
                audioTrack.flush();

                double freq = convertMidiToFreq(midi);
                short samples[] = new short[buffsize];


                for(int i=0; i < buffsize; i++) {
                    if (i<buffsize/portion){
                        short wavePoint =  (short) (0.25* amp * Math.sin(ph) +
                                0.25* amp * Math.sin(ph*2)+
                                0.25* amp * Math.sin(ph*3)+
                                0.25* amp * Math.sin(ph*4));
                        samples[i] = wavePoint;
                        ph += twopi * freq / samplingRate;
                    }
                    else{
                        samples[i] = 0;

                    }
                }
                audioTrack.write(samples, 0, buffsize);
                audioTrack.setLoopPoints(0,(buffsize-1)/2,-1);
                audioTrack.play();

            }
        });

        stop.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                audioTrack.stop();
                audioTrack.flush();

            }
        });









        /*
        volumeInString = Float.toString(playVolume);
        volume.setText(volumeInString);
        streamID = sp.play(soundId,0,0,1,0,playBackRate);


        play.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                sp.stop(streamID);
                if (octaveLevel ==0){
                    playBackRate = (float)0.5;
                }
                else if(octaveLevel == 2){
                    playBackRate= (float) 2.0;
                }
                else{
                    playBackRate = (float) 1.0;
                }
                streamID = sp.play(soundId,playVolume,playVolume,1,0,playBackRate);
                volumeInString = Float.toString(playVolume);
                volume.setText(volumeInString);

            }
        });
        softer.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                playVolume = playVolume - changeVolume;

                if (playVolume<0.1) {
                    playVolume = 0;
                }
                volumeInString = Float.toString(playVolume);
                volume.setText(volumeInString);
            }
        });
        louder.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                playVolume = playVolume + changeVolume;

                if (playVolume>0.9) {
                    playVolume = 1;
                }
                volumeInString = Float.toString(playVolume);
                volume.setText(volumeInString);

            }
        });
        higher.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                octaveLevel+=1;
                if (octaveLevel>2){
                    octaveLevel = 2;
                }

            }
        });
        lower.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                octaveLevel-=1;
                if (octaveLevel<0){
                    octaveLevel = 0;
                }

            }
        });
        */
    }

    private static double convertMidiToFreq(int midi){
        if (midi ==0){
            return 0;
        }
        else{
            double freq = 440.0 * Math.pow(2,(midi-69.0)/12.0);
            return freq;
        }
    }
    private static double[] linspace(double min, double max, int points) {
        double[] d = new double[points];
        for (int i = 0; i < points; i++){
            d[i] = min + i * (max - min) / (points - 1);
        }
        return d;
    }

    private static short[] createADSRFunction(int buffsize, int portion){
        int attackDuration = (int)((buffsize/portion)*0.35);
        int decayDuration = (int)((buffsize/portion)*0.2);
        int sustainDuration = (int)((buffsize/portion) *0.25);
        int releaseDuration = (int)((buffsize/portion) *0.2);

        double[] attackValue = linspace(0,1,attackDuration);
        double[] decayValue = linspace(1,0.5,attackDuration);
        double[] releaseValue = linspace(0.5,0,attackDuration);

     //   Log.d("attack",Short.toString((short)attackValue[1]));

        short[] signal = new short[buffsize];

        for (int i = 0; i<attackDuration;i++){
            signal[i] = (short)attackValue[i];
        }
        for (int i = 0; i<decayDuration;i++){
            signal[attackDuration+i] = (short)decayValue[i];
        }
        for (int i = 0; i<sustainDuration;i++){
            signal[attackDuration+decayDuration+i] = (short) 0.5;
        }
        for (int i = 0; i<releaseDuration;i++){
            signal[attackDuration+decayDuration+sustainDuration+i] = (short)releaseValue[i];
        }
      //  Log.d("signal",Arrays.toString(signal));

        for (int i=attackDuration+decayDuration+sustainDuration+releaseDuration;i<buffsize;i++){
            signal[i]=0;
        }
        return signal;

    }

}
